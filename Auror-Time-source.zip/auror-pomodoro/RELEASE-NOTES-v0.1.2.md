# Auror Time v0.1.2

The current preview of Auror Time is a local Pomodoro timer for focus sessions.

## What's included

- A circular countdown timer with 15, 25, 45 and 60-minute presets, plus a custom duration from 1 to 180 minutes.
- An optional task name shown beneath the timer.
- English and Russian interface options.
- The `Gong — enhanced.wav` sound when a session ends.
- Local session history.

## Run it

Open `Auror Time.html` in a modern browser. The standalone file includes the app and sound; no installation, server or internet connection is required.

## Local data

The timer state and completed sessions are stored in the browser on this device. They are not uploaded or synced. To keep seeing the same history, use the same browser and avoid private browsing mode.
