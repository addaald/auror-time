(() => {
  const $ = (id) => document.getElementById(id);
  const core = window.PomodoroCore;
  const i18n = window.PomodoroI18n;
  const STORAGE_KEY = 'auror-time-pomodoro-v1';
  const DEFAULT_SECONDS = 25 * 60;
  const CIRCUMFERENCE = 2 * Math.PI * 148;
  const completionAudio = new Audio(new URL('assets/gong.wav', document.baseURI).href);
  completionAudio.preload = 'auto';
  const els = {
    date: $('dateLabel'), task: $('taskInput'), taskCaption: $('taskCaption'), time: $('timeDisplay'),
    ring: $('ringProgress'), stage: document.querySelector('.timer-stage'), statusDot: $('statusDot'),
    status: $('statusLabel'), start: $('startButton'), startLabel: $('startLabel'), reset: $('resetButton'),
    custom: $('customMinutes'), trackTab: $('trackTab'), sessionsTab: $('sessionsTab'),
    trackView: $('trackView'), sessionsView: $('sessionsView'), sessionCount: $('sessionCount'),
    sessionList: $('sessionList'), todayTotal: $('todayTotal'), toast: $('toast'),
    langEn: $('langEn'), langRu: $('langRu'), brand: document.querySelector('.brand'), mainNav: $('mainNav')
  };

  function readState() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
    catch { return {}; }
  }
  const saved = readState();
  let language = saved.language === 'ru' ? 'ru' : 'en';
  const t = (key) => i18n.getText(language, key);
  let duration = Number.isInteger(saved.duration) && saved.duration >= 60 && saved.duration <= 10800 ? saved.duration : DEFAULT_SECONDS;
  let remaining = Number.isFinite(saved.remaining) && saved.remaining >= 0 ? Math.floor(saved.remaining) : duration;
  let task = typeof saved.task === 'string' ? saved.task.slice(0, 64) : '';
  let sessions = Array.isArray(saved.sessions) ? saved.sessions.filter(isValidSession).slice(0, 100) : [];
  let running = Boolean(saved.running && Number.isFinite(saved.endAt));
  let endAt = running ? saved.endAt : 0;
  if (running) {
    remaining = core.remainingSeconds(duration * 1000, endAt);
    if (remaining === 0) completeSession();
  }

  function isValidSession(item) {
    return item && typeof item === 'object' && typeof item.task === 'string' && Number.isFinite(item.minutes) && typeof item.at === 'string';
  }
  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ duration, remaining, task, language, running, endAt, sessions })); }
    catch { showToast(t('toastStorage')); }
  }
  function setStatus(text, kind = '') {
    els.status.textContent = text;
    els.statusDot.className = `status-dot${kind ? ` ${kind}` : ''}`;
  }
  function applyLanguage() {
    const locale = i18n.getDateLocale(language);
    document.documentElement.lang = language;
    els.brand.setAttribute('aria-label', t('appAria'));
    els.mainNav.setAttribute('aria-label', t('navAria'));
    els.trackView.setAttribute('aria-label', t('timerAria'));
    els.langEn.setAttribute('aria-label', t('languageEnglish'));
    els.langRu.setAttribute('aria-label', t('languageRussian'));
    els.langEn.classList.toggle('active', language === 'en');
    els.langRu.classList.toggle('active', language === 'ru');
    els.langEn.setAttribute('aria-pressed', String(language === 'en'));
    els.langRu.setAttribute('aria-pressed', String(language === 'ru'));
    els.trackTab.textContent = t('navTrack');
    $('sessionsLabel').textContent = t('navSessions');
    document.querySelector('.language-switch').setAttribute('aria-label', t('languageGroup'));
    document.querySelector('.task-input-wrap label').textContent = t('taskLabel');
    els.task.placeholder = t('taskPlaceholder');
    document.querySelector('.control-label').textContent = t('duration');
    document.querySelector('.duration-options').setAttribute('aria-label', t('durationGroup'));
    els.custom.setAttribute('aria-label', t('customMinutes'));
    document.querySelector('.custom-duration span').textContent = t('minSuffix');
    els.reset.setAttribute('aria-label', t('reset'));
    els.reset.title = t('reset');
    $('sessionsHeading').textContent = t('sessionsTitle');
    document.querySelector('.view-eyebrow').textContent = t('sessionsEyebrow');
    document.querySelector('.privacy-note').textContent = t('privacy');
    const footer = document.querySelector('.app-footer');
    footer.children[0].textContent = t('footerLeft');
    footer.children[2].textContent = t('footerRight');
    els.date.textContent = new Intl.DateTimeFormat(locale, { weekday: 'short', day: 'numeric', month: 'short' }).format(new Date()).replace('.', '').toUpperCase();
  }
  function render() {
    applyLanguage();
    els.time.textContent = core.formatTime(remaining);
    document.title = `${core.formatTime(remaining)} — ${t('appTitle')}`;
    els.task.value = task;
    els.taskCaption.textContent = task.trim() || (remaining === 0 ? t('taskComplete') : t('taskEmpty'));
    els.taskCaption.title = task;
    const progress = duration ? Math.max(0, Math.min(1, remaining / duration)) : 1;
    els.ring.style.strokeDasharray = `${CIRCUMFERENCE}`;
    els.ring.style.strokeDashoffset = `${CIRCUMFERENCE * (1 - progress)}`;
    els.stage.classList.toggle('is-running', running);
    els.stage.classList.toggle('is-complete', !running && remaining === 0);
    els.startLabel.textContent = running ? t('pause') : (remaining === duration || remaining === 0 ? t('start') : t('resume'));
    els.start.querySelector('.button-icon').textContent = running ? 'Ⅱ' : '▶';
    els.task.disabled = running;
    document.querySelectorAll('.duration-chip').forEach((button) => {
      const selected = Number(button.dataset.minutes) * 60 === duration;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', String(selected));
      button.disabled = running;
    });
    els.custom.disabled = running;
    setStatus(running ? t('statusRunning') : remaining === 0 ? t('statusComplete') : t('statusOff'), running ? 'running' : remaining === 0 ? 'complete' : '');
    const today = new Date().toDateString();
    const todaySessions = sessions.filter((session) => new Date(session.at).toDateString() === today);
    els.sessionCount.textContent = String(sessions.length);
    els.todayTotal.textContent = i18n.formatTodayTotal(todaySessions.reduce((sum, session) => sum + session.minutes, 0), language);
    renderSessions();
  }
  function renderSessions() {
    els.sessionList.replaceChildren();
    if (!sessions.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = t('emptySessions');
      els.sessionList.append(empty);
      return;
    }
    sessions.forEach((session) => {
      const card = document.createElement('article');
      card.className = 'session-card';
      const main = document.createElement('div');
      main.className = 'session-main';
      const name = document.createElement('div');
      name.className = 'session-name';
      name.textContent = session.task || t('sessionFallback');
      const meta = document.createElement('div');
      meta.className = 'session-meta';
      meta.textContent = new Date(session.at).toLocaleString(i18n.getDateLocale(language), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
      const durationLabel = document.createElement('div');
      durationLabel.className = 'session-duration';
      durationLabel.textContent = i18n.formatMinutes(session.minutes, language);
      main.append(name, meta);
      card.append(main, durationLabel);
      els.sessionList.append(card);
    });
  }
  function showToast(text) {
    els.toast.textContent = text;
    els.toast.classList.add('visible');
    clearTimeout(showToast.timeout);
    showToast.timeout = setTimeout(() => els.toast.classList.remove('visible'), 2300);
  }
  function setDuration(minutes) {
    if (running) return;
    duration = minutes * 60;
    remaining = duration;
    endAt = 0;
    persist();
    render();
  }
  function playChime() {
    try {
      completionAudio.pause();
      completionAudio.currentTime = 0;
      const playback = completionAudio.play();
      if (playback && typeof playback.catch === 'function') playback.catch(() => {});
    } catch { /* Sound is optional; timer state still completes. */ }
  }
  function completeSession() {
    if (!running && remaining === 0) return;
    running = false;
    remaining = 0;
    endAt = 0;
    sessions.unshift({ task: task.trim(), minutes: Math.round(duration / 60), at: new Date().toISOString() });
    sessions = sessions.slice(0, 100);
    persist();
    render();
    playChime();
    showToast(t('toastComplete'));
  }
  function refreshClock() {
    if (!running) return;
    const next = core.remainingSeconds(duration * 1000, endAt);
    if (next === 0) { completeSession(); return; }
    if (next !== remaining) {
      remaining = next;
      persist();
      render();
    }
  }
  function toggleTimer() {
    if (running) {
      refreshClock();
      if (!running) return;
      running = false;
      remaining = core.remainingSeconds(duration * 1000, endAt);
      endAt = 0;
    } else {
      if (remaining === 0) remaining = duration;
      running = true;
      endAt = Date.now() + remaining * 1000;
    }
    persist();
    render();
  }
  function resetTimer() {
    running = false;
    endAt = 0;
    remaining = duration;
    persist();
    render();
  }
  function showView(view) {
    const sessionsActive = view === 'sessions';
    els.trackView.hidden = sessionsActive;
    els.sessionsView.hidden = !sessionsActive;
    els.trackTab.classList.toggle('active', !sessionsActive);
    els.sessionsTab.classList.toggle('active', sessionsActive);
    els.trackTab.toggleAttribute('aria-current', !sessionsActive);
    els.sessionsTab.toggleAttribute('aria-current', sessionsActive);
  }

  function setLanguage(nextLanguage) {
    if (nextLanguage !== 'en' && nextLanguage !== 'ru') return;
    language = nextLanguage;
    persist();
    render();
  }
  els.start.addEventListener('click', toggleTimer);
  els.reset.addEventListener('click', resetTimer);
  els.langEn.addEventListener('click', () => setLanguage('en'));
  els.langRu.addEventListener('click', () => setLanguage('ru'));
  els.task.addEventListener('input', () => { task = els.task.value.slice(0, 64); els.taskCaption.textContent = task.trim() || t('taskEmpty'); persist(); });
  document.querySelectorAll('.duration-chip').forEach((button) => button.addEventListener('click', () => setDuration(Number(button.dataset.minutes))));
  els.custom.addEventListener('change', () => {
    const minutes = core.normalizeMinutes(els.custom.value);
    if (minutes === null) { els.custom.value = ''; showToast(t('toastInvalid')); return; }
    setDuration(minutes);
    els.custom.value = '';
  });
  els.trackTab.addEventListener('click', () => showView('track'));
  els.sessionsTab.addEventListener('click', () => showView('sessions'));
  window.addEventListener('keydown', (event) => {
    const tag = document.activeElement?.tagName;
    if ((event.code === 'Space' || event.code === 'Enter') && !['INPUT', 'TEXTAREA', 'BUTTON'].includes(tag)) {
      if (event.code === 'Space') { event.preventDefault(); toggleTimer(); }
    }
  });
  render();
  persist();
  window.setInterval(refreshClock, 200);
})();
