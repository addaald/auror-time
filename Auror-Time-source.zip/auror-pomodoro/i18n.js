const COPY = {
  en: {
    appTitle: 'Auror Time — Focus', appAria: 'Auror Time — timer', navAria: 'Navigation', languageGroup: 'Language',
    navTrack: 'Track', navSessions: 'Sessions', taskLabel: 'WHAT ARE WE WORKING ON?',
    taskPlaceholder: 'e.g. Create UI', taskEmpty: 'Choose a task to begin', taskComplete: 'Session complete',
    timerAria: 'Pomodoro timer', duration: 'Duration', durationGroup: 'Session duration',
    customMinutes: 'Custom duration in minutes', minSuffix: 'min', start: 'Start focus', pause: 'Pause',
    resume: 'Resume', reset: 'Reset timer', statusOff: 'Timer is off', statusRunning: 'Focus session in progress',
    statusComplete: 'Session complete', sessionsEyebrow: 'YOUR WORK', sessionsTitle: 'Sessions',
    todayUnit: 'min today', emptySessions: 'Completed focus sessions will show up here. They stay only in this browser.',
    privacy: 'History is stored locally in this browser.', footerLeft: 'One stretch at a time.',
    footerRight: 'Only on this Mac', toastComplete: 'Session complete — nice work',
    toastInvalid: 'Choose between 1 and 180 minutes', toastStorage: 'Could not save in this browser',
    sessionFallback: 'Focus session', languageEnglish: 'Switch language to English', languageRussian: 'Переключить язык на русский'
  },
  ru: {
    appTitle: 'Auror Time — Фокус', appAria: 'Auror Time — таймер', navAria: 'Навигация', languageGroup: 'Язык',
    navTrack: 'Трек', navSessions: 'Сессии', taskLabel: 'НАД ЧЕМ РАБОТАЕМ?',
    taskPlaceholder: 'Например, создать UI', taskEmpty: 'Пора выбрать задачу', taskComplete: 'Сессия завершена',
    timerAria: 'Таймер помодоро', duration: 'Длительность', durationGroup: 'Длительность сессии',
    customMinutes: 'Своя длительность в минутах', minSuffix: 'мин', start: 'Начать фокус', pause: 'Пауза',
    resume: 'Продолжить', reset: 'Сбросить таймер', statusOff: 'Таймер выключен', statusRunning: 'Фокус-сессия идёт',
    statusComplete: 'Сессия завершена', sessionsEyebrow: 'ТВОЯ РАБОТА', sessionsTitle: 'Сессии',
    todayUnit: 'мин сегодня', emptySessions: 'Завершённые фокус-сессии появятся здесь. Они останутся только в этом браузере.',
    privacy: 'История хранится локально в этом браузере.', footerLeft: 'Один отрезок за раз.',
    footerRight: 'Только на этом Mac', toastComplete: 'Сессия завершена — хорошая работа',
    toastInvalid: 'Выбери от 1 до 180 минут', toastStorage: 'Не удалось сохранить данные в браузере',
    sessionFallback: 'Фокус-сессия', languageEnglish: 'Switch language to English', languageRussian: 'Переключить язык на русский'
  }
};

function getText(language, key) {
  const selected = COPY[language] || COPY.en;
  return selected[key] ?? COPY.en[key] ?? key;
}

function getDateLocale(language) {
  return language === 'ru' ? 'ru-RU' : 'en-US';
}

function formatMinutes(minutes, language) {
  return `${minutes} ${getText(language, 'minSuffix')}`;
}

function formatTodayTotal(minutes, language) {
  return `${formatMinutes(minutes, language)} ${language === 'ru' ? 'сегодня' : 'today'}`;
}

const i18nApi = { getText, getDateLocale, formatMinutes, formatTodayTotal };
if (typeof module !== 'undefined' && module.exports) module.exports = i18nApi;
if (typeof window !== 'undefined') window.PomodoroI18n = i18nApi;
