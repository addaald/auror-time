const test = require('node:test');
const assert = require('node:assert/strict');
const { formatTime, remainingSeconds, normalizeMinutes } = require('../timer-core.js');

test('formats a Pomodoro duration as minutes and seconds', () => {
  assert.equal(formatTime(1500), '25:00');
  assert.equal(formatTime(59), '00:59');
  assert.equal(formatTime(3601), '60:01');
});

test('computes remaining time from an absolute end timestamp without timer drift', () => {
  assert.equal(remainingSeconds(25 * 60 * 1000, 10_000, 1_250), 9);
  assert.equal(remainingSeconds(25 * 60 * 1000, 10_000, 10_001), 0);
});

test('accepts only whole minute durations from 1 to 180', () => {
  assert.equal(normalizeMinutes('25'), 25);
  assert.equal(normalizeMinutes('1.5'), null);
  assert.equal(normalizeMinutes('181'), null);
  assert.equal(normalizeMinutes(''), null);
});
