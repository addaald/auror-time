const test = require('node:test');
const assert = require('node:assert/strict');
const { getText, formatMinutes, getDateLocale } = require('../i18n.js');

test('uses English as the default UI language', () => {
  assert.equal(getText('en', 'taskLabel'), 'WHAT ARE WE WORKING ON?');
  assert.equal(getText('en', 'navTrack'), 'Track');
  assert.equal(getDateLocale('en'), 'en-US');
  assert.equal(getText('en', 'languageGroup'), 'Language');
});

test('returns Russian UI copy when Russian is selected', () => {
  assert.equal(getText('ru', 'taskLabel'), 'НАД ЧЕМ РАБОТАЕМ?');
  assert.equal(getText('ru', 'navTrack'), 'Трек');
  assert.equal(getDateLocale('ru'), 'ru-RU');
});

test('formats session durations in both languages', () => {
  assert.equal(formatMinutes(1, 'en'), '1 min');
  assert.equal(formatMinutes(25, 'ru'), '25 мин');
  assert.equal(formatMinutes(2, 'ru'), '2 мин');
});
