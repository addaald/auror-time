function formatTime(totalSeconds) {
  const value = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  const minutes = Math.floor(value / 60);
  const seconds = value % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function remainingSeconds(_durationMs, endAtMs, nowMs = Date.now()) {
  if (!Number.isFinite(endAtMs) || !Number.isFinite(nowMs)) return 0;
  return Math.max(0, Math.ceil((endAtMs - nowMs) / 1000));
}

function normalizeMinutes(value) {
  const text = String(value ?? '').trim();
  if (!/^\d+$/.test(text)) return null;
  const minutes = Number(text);
  return Number.isSafeInteger(minutes) && minutes >= 1 && minutes <= 180 ? minutes : null;
}

const api = { formatTime, remainingSeconds, normalizeMinutes };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.PomodoroCore = api;
